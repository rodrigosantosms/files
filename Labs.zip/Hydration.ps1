﻿Param(
    [string] [Parameter(Mandatory = $true)] $alias,
    [string] [Parameter(Mandatory = $true)] $adminpassword
)

Write-Host 'Please log into Azure now' -foregroundcolor Green;
Login-AzAccount

$Subscription = (Get-AzSubscription) | Select-Object Name, Id | Out-GridView -Title "Select Azure Subscription " -PassThru

Select-AzSubscription -SubscriptionName $Subscription.Name

#$aadAppName =$alias +"msreadylabapp" #not in use
#$defaultHomePage ="http://"+"$azureadappname" #not in use
#$IDENTIFIERURI =[string]::Format("http://localhost:8080/{0}",[Guid]::NewGuid().ToString("N")); #not in use
$keyvaultrg = $alias + '-keyvault-rg'
$keyvaultName = $alias + '-akeyvault'
$loganalyticsname = $alias + '-loganalyticsready'
$loganalyticsrg = $alias + '-loganalytics-rg'
$location = "East US"
#$aadClientSecret = "abc123" #not in use

$outputpath = ".\hydrationoutput-$alias.txt"

$function = @("keyvault", "network", "dc", "loganalytics", "jumpbox")

foreach ($rg in $function) {
    $rgname = $alias + '-' + $rg + '-rg'
    New-AzResourceGroup -Name $rgname -Location $Location | Out-Null
    Write-Host "Created Resource Group $rgname" -BackgroundColor Green -ForegroundColor DarkBlue 
}
Try {
    $resGroup = Get-AzResourceGroup -Name $keyvaultrg -ErrorAction SilentlyContinue
}
Catch [System.ArgumentException] {
    Write-Host "Couldn't find resource group:  ($keyvaultrg)"
    $resGroup = $null;
}

#Create a new resource group if it doesn't exist
if (-not $resGroup) {
    Write-Host "Creating new resource group:  ($keyvaultrg)"
    $resGroup = New-AzResourceGroup -Name $keyvaultrg -Location $location
    Write-Host "Created a new resource group named $keyvaultrg to place keyVault"
}

Try {
    $keyVault = Get-AzKeyVault -VaultName $keyvaultName -ErrorAction SilentlyContinue
}
Catch [System.ArgumentException] {
    Write-Host "Couldn't find Key Vault: $keyVaultName"
    $keyVault = $null
}
    
#Create a new vault if vault doesn't exist
if (-not $keyVault) {
    Write-Host "Creating new key vault: ($keyVaultName)"
    $keyVault = New-AzKeyVault -VaultName $keyVaultName -ResourceGroupName $keyvaultrg -Sku Standard -Location $location
    Write-Host "Created a new KeyVault named $keyVaultName to store encryption keys"
}

# Specify privileges to the vault for the AAD application - https://msdn.microsoft.com/en-us/library/mt603625.aspx
Set-AzKeyVaultAccessPolicy -VaultName $keyVaultName -EnabledForDiskEncryption -EnabledForTemplateDeployment
$seckey1 = ConvertTo-SecureString -String $adminpassword -AsPlainText -Force
Set-AzKeyVaultSecret -Name adminpassword -SecretValue $seckey1 -VaultName $keyvaultName 

Try {
    $loganalyticsworkspace = Get-AzOperationalInsightsWorkspace -ResourceGroupName $loganalyticsrg -Name $loganalyticsname -ErrorAction SilentlyContinue
}
Catch [System.ArgumentException] {
    Write-Host "Couldn't find loganalytics Workspace:  ($loganalyticsname)"
    $loganalyticsworkspace = $null
}

#Create a new loganalytics Workspace if it doesn't exist
if (-not $loganalyticsworkspace) {
    Write-Host "Creating new Log Analytics Workspace:  ($loganalyticsname)"
    $loganalyticsworkspace = New-AzOperationalInsightsWorkspace -Location $location -Name $loganalyticsname -ResourceGroupName $loganalyticsrg  -Force
    # $loganalyticsworkspace=New-AzOperationalInsightsWorkspace -Location $location -Name $loganalyticsname -ResourceGroupName $loganalyticsrg  -Force -Sku "pernode"
    Write-Host "Created a new loganalytics WorkSpace named $loganalyticsname for Monitoring and Log analytics"
}

$sharedkey = Get-AzOperationalInsightsWorkspaceSharedKey -Name $loganalyticsname -ResourceGroupName $loganalyticsrg
$key = $sharedkey.PrimarySharedKey
$loganalyticsclientid = $loganalyticsworkspace.CustomerId.Guid

if ((Test-Path  $outputpath) -eq 'True' ) {
    Clear-Content $outputpath
}
       
Write-Output "`t`r`nLoganalytics WorkSpace ID  ---------->>" | Out-File $outputpath -Append
$loganalyticsclientid | Out-File $outputpath -Append
Write-Output "`r`nLoganalytics Shared Key  ---------->>>>" | Out-File $outputpath -Append
$key | Out-File $outputpath -Append

Start $outputpath

Write-Host "Please note down below aadClientID, ,loganalyticsWorkspace-Client-id, loganalyticsSharedkey and refer these values in $outputpath  " -foregroundcolor Green
Write-Host "`t aadClientID: $aadClientID" -foregroundcolor Green
Write-Host "`t loganalyticsWorkspaceID: $loganalyticsclientid" -foregroundcolor Green
Write-Host "`t loganalyticsSharedKey: $key" -foregroundcolor Green
Write-Host "`t keyVaultNAme: $keyvaultName" -foregroundcolor Green